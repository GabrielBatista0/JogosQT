# import sys
# from PyQt5.QtWidgets import QMainWindow, QApplication, QLabel, QPushButton
# from PyQt5.QtGui import QMovie
#
#
# # from jokenpo import gamejokenpo
# # from jogodavelha import velha
#
#
# class Janela(QMainWindow):
#     def __init__(self):
#         super().__init__()
#         self.setMinimumSize(800, 500)
#         self.setWindowTitle('SELECT A GAME')
#
#         self.movie = QMovie("menu.gif")
#         self.gif = QLabel(self)
#         self.gif.setMovie(self.movie)
#         self.gif.resize(800, 500)
#         self.gif.setScaledContents(True)
#         self.movie.start()
#
#
#
#         self.btn_forca = QPushButton(self)
#         self.btn_forca.setStyleSheet('')
#         self.btn_forca.resize(150, 60)
#         self.btn_forca.move(100, 400)
#         # self.btn_forca.clicked.connect(self.select_forca)
#
#         self.btn_velha = QPushButton(self)
#         self.btn_velha.setStyleSheet('')
#         self.btn_velha.resize(150, 60)
#         self.btn_velha.move(300, 400)
#         # self.btn_velha.clicked.connect(self.select_velha)
#
#         self.btn_jokenpo = QPushButton(self)
#         self.btn_jokenpo.setStyleSheet('')
#         self.btn_jokenpo.resize(150, 60)
#         self.btn_jokenpo.move(500, 400)
#         # self.btn_jokenpo.clicked.connect(self.select_jokenpo)
#         self.show()
#
#     # def select_velha(self):
#     #     v.show()
#     #
#     # def select_jokenpo(self):
#     #     gamejokenpo.Jokenpo().__init__()
#     #
#     # def select_forca(self):
#     #     gamejokenpo.Jokenpo().__init__()
#
#
# if __name__ == '__main__':
#     aplicacao = QApplication(sys.argv)
#     j = Janela()
#     # v = velha.game()
#     sys.exit(aplicacao.exec())
