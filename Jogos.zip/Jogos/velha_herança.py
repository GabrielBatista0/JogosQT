from PyQt5 import QtWidgets

from velha import Velha

class Configuracao_Jogo_da_Velha(Velha):
    def __init__(self, jogo_da_velha):
        self.setupUi(jogo_da_velha)
        self.btn_1.clicked.connect(self.click_1)
        self.btn_2.clicked.connect(self.click_2)
        self.btn_3.clicked.connect(self.click_3)
        self.btn_4.clicked.connect(self.click_4)
        self.btn_5.clicked.connect(self.click_5)
        self.btn_6.clicked.connect(self.click_6)
        self.btn_7.clicked.connect(self.click_7)
        self.btn_8.clicked.connect(self.click_8)
        self.btn_9.clicked.connect(self.click_9)
        self.btn_reset.clicked.connect(self.reset)
        self.jogada = True
        self.valor1 = 0
        self.valor2 = 0
        self.valor3 = 0
        self.valor4 = 0
        self.valor5 = 0
        self.valor6 = 0
        self.valor7 = 0
        self.valor8 = 0
        self.valor9 = 0
        self.ganhador = 0


    def click_1(self):
        if self.jogada:
            self.btn_1.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor1 = 1
        else:
            self.btn_1.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor1 = 2
        self.btn_1.setEnabled(False)
        self.jogo()

    def click_2(self):
        if self.jogada:
            self.btn_2.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor2 = 1
        else:
            self.btn_2.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor2 = 2
        self.btn_2.setEnabled(False)
        self.jogo()

    def click_3(self):
        if self.jogada:
            self.btn_3.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor3 = 1
        else:
            self.btn_3.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor3 = 2
        self.btn_3.setEnabled(False)
        self.jogo()

    def click_4(self):
        if self.jogada:
            self.btn_4.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor4 = 1
        else:
            self.btn_4.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor4 = 2
        self.btn_4.setEnabled(False)
        self.jogo()

    def click_5(self):
        if self.jogada:
            self.btn_5.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor5 = 1
        else:
            self.btn_5.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor5 = 2
        self.btn_5.setEnabled(False)
        self.jogo()

    def click_6(self):
        if self.jogada:
            self.btn_6.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor6 = 1
        else:
            self.btn_6.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor6 = 2
        self.btn_6.setEnabled(False)
        self.jogo()

    def click_7(self):
        if self.jogada:
            self.btn_7.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor7 = 1
        else:
            self.btn_7.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor7 = 2
        self.btn_7.setEnabled(False)
        self.jogo()

    def click_8(self):
        if self.jogada:
            self.btn_8.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor8 = 1
        else:
            self.btn_8.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor8 = 2
        self.btn_8.setEnabled(False)
        self.jogo()

    def click_9(self):
        if self.jogada:
            self.btn_9.setStyleSheet('border-image: url(x.png); background-size: 5px;')
            self.jogada = False
            self.valor9 = 1
        else:
            self.btn_9.setStyleSheet('border-image: url(O.png); background-size: 5px;')
            self.jogada = True
            self.valor9 = 2
        self.btn_9.setEnabled(False)
        self.jogo()

    def reset(self):
        # for i in range(1,9):
        #     self.btn_i.setStyleSheet('border-image: url(O.png); background-size: 5px;')
        self.btn_1.setStyleSheet('border-image: none;')
        self.btn_2.setStyleSheet('border-image: none;')
        self.btn_3.setStyleSheet('border-image: none;')
        self.btn_4.setStyleSheet('border-image: none;')
        self.btn_5.setStyleSheet('border-image: none;')
        self.btn_6.setStyleSheet('border-image: none;')
        self.btn_7.setStyleSheet('border-image: none;')
        self.btn_8.setStyleSheet('border-image: none;')
        self.btn_9.setStyleSheet('border-image: none;')
        self.btn_1.setEnabled(True)
        self.btn_2.setEnabled(True)
        self.btn_3.setEnabled(True)
        self.btn_4.setEnabled(True)
        self.btn_5.setEnabled(True)
        self.btn_6.setEnabled(True)
        self.btn_7.setEnabled(True)
        self.btn_8.setEnabled(True)
        self.btn_9.setEnabled(True)
        self.jogada = True
        self.valor1 = 0
        self.valor2 = 0
        self.valor3 = 0
        self.valor4 = 0
        self.valor5 = 0
        self.valor6 = 0
        self.valor7 = 0
        self.valor8 = 0
        self.valor9 = 0
        self.ganhador = 0
        self.label_inferior.setText("RESULTADO")

    def jogo(self):
        if self.valor1 == 1 and self.valor2 == 1 and self.valor3 == 1:
            self.ganhador = 1
            self.desabilitar()

        elif self.valor1 == 2 and self.valor2 == 2 and self.valor3 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor4 == 1 and self.valor5 == 1 and self.valor6 == 1:
            self.ganhador = 1
            self.desabilitar()
        elif self.valor4 == 2 and self.valor5 == 2 and self.valor6 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor7 == 2 and self.valor8 == 2 and self.valor9 == 2:
            self.ganhador = 2
            self.desabilitar()

        elif self.valor7 == 1 and self.valor8 == 1 and self.valor9 == 1:
            self.ganhador = 1
            self.desabilitar()
        else:
            pass

        if self.valor1 == 1 and self.valor4 == 1 and self.valor7 == 1:
            self.ganhador = 1
            self.desabilitar()
        elif self.valor1 == 2 and self.valor4 == 2 and self.valor7 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor2 == 1 and self.valor5 == 1 and self.valor8 == 1:
            self.ganhador = 1
            self.desabilitar()
        elif self.valor2 == 2 and self.valor5 == 2 and self.valor8 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor3 == 1 and self.valor6 == 1 and self.valor9 == 1:
            self.ganhador = 1
            self.desabilitar()
        elif self.valor3 == 2 and self.valor6 == 2 and self.valor9 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor3 == 1 and self.valor5 == 1 and self.valor7 == 1:
            self.ganhador = 1
            self.desabilitar()

        elif self.valor3 == 2 and self.valor5 == 2 and self.valor7 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            pass

        if self.valor1 == 1 and self.valor5 == 1 and self.valor9 == 1:
            self.ganhador = 1
            self.desabilitar()

        elif self.valor1 == 2 and self.valor5 == 2 and self.valor9 == 2:
            self.ganhador = 2
            self.desabilitar()
        else:
            if self.valor1 != 0 and self.valor2 != 0 and self.valor3 != 0 and self.valor4 != 0 and self.valor5 != 0 and self.valor6 != 0 and self.valor7 != 0 and self.valor8 != 0 and self.valor9 != 0:
                self.desabilitar()

    def desabilitar(self):
        botoes = [self.btn_1, self.btn_2, self.btn_3, self.btn_4, self.btn_5, self.btn_6, self.btn_7, self.btn_8,
                  self.btn_9]
        for i in botoes:
            i.setEnabled(False)
        self.final()

    def final(self):
        if self.ganhador == 1:
            self.label_inferior.setText("JOGADOR 'X' GANHOU")
        elif self.ganhador == 2:
            self.label_inferior.setText("JOGADOR 'O' GANHOU")
        else:
            self.label_inferior.setText("DEU VELHA")


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    jogo_da_velha = QtWidgets.QMainWindow()
    config_jogo_da_velha = Configuracao_Jogo_da_Velha(jogo_da_velha)
    jogo_da_velha.show()
    app.exec()