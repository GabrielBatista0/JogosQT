# import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from velha_herança import Configuracao_Jogo_da_Velha
# from PyQt5.QtWidgets import QMainWindow, QApplication, QLabel, QPushButton
# from PyQt5.QtGui import QMovie


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, 0, 800, 600))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("The games/The games.png"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")

        self.btnVelha = QtWidgets.QPushButton(self.centralwidget)
        self.btnVelha.setGeometry(QtCore.QRect(120, 370, 161, 91))
        self.btnVelha.setStyleSheet("background:rgba(255, 255, 255, 0)")
        self.btnVelha.setText("")
        self.btnVelha.setObjectName("btnVelha")
        self.btnVelha.clicked.connect(self.velha)

        self.btnForca = QtWidgets.QPushButton(self.centralwidget)
        self.btnForca.setGeometry(QtCore.QRect(320, 370, 161, 91))
        self.btnForca.setStyleSheet("background:rgba(255, 255, 255, 0)")
        self.btnForca.setText("")
        self.btnForca.setObjectName("btnForca")
        self.btnJokempo = QtWidgets.QPushButton(self.centralwidget)
        self.btnJokempo.setGeometry(QtCore.QRect(530, 370, 151, 91))
        self.btnJokempo.setStyleSheet("background:rgba(255, 255, 255, 0)")
        self.btnJokempo.setText("")
        self.btnJokempo.setObjectName("btnJokempo")
        self.btnJokempo.clicked.connect(self.jokempo)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))

    def velha(self):
        MainWindow.close()
        self.window = QtWidgets.QMainWindow()
        self.ui = Configuracao_Jogo_da_Velha()
        self.ui.setupUi(self.window)
        self.window.show()
    def forca(self):
        pass
    def jokempo(self):
        print("oi")



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
